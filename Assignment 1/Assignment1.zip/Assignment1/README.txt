The source file is titled "ground_truth.py". To run the program, ensure that scipy and numpy are
installed. The command to run the source code is "python ground_truth.py".

Ensure that the "music_speech" folder containing the "music_wav" and "speech_wav" folders is in
the same directory as the source code. Also ensure that the file "music_speech.mf.txt" containing
the names of the wav files is also in the same directory. The program will run and collate the
data, which will be written to a CSV file with the title "answers.csv"